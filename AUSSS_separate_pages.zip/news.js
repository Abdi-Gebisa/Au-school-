// Public announcements page. Use only the Supabase publishable/anon key, never a service-role key.
const SUPABASE_URL="https://hdgxcdpeelpbjnrtehhv.supabase.co";
const SUPABASE_PUBLISHABLE_KEY="PASTE_YOUR_SB_PUBLISHABLE_KEY_HERE";
const status=document.getElementById("newsStatus"),list=document.getElementById("announcementList");
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
if(!SUPABASE_PUBLISHABLE_KEY.startsWith("sb_publishable_")){status.textContent="Announcements will appear here after the site owner configures the Supabase publishable key.";}else{
 const db=window.supabase.createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY);
 db.from("announcements").select("id,title,content,created_at").eq("published",true).order("created_at",{ascending:false}).limit(30).then(({data,error})=>{
  if(error){status.textContent="Announcements are temporarily unavailable.";return;}
  if(!data?.length){status.textContent="No announcements have been published yet.";return;}
  status.textContent="";list.innerHTML=data.map(x=>`<article class="announcement"><h3>${esc(x.title)}</h3><time>${esc(new Date(x.created_at).toLocaleDateString())}</time><p>${esc(x.content)}</p></article>`).join("");
 });
}
